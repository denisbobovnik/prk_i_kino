package si.um.feri.praktikum;

public class Comment {

	private int commentID;
	private String content;
	private int moviesID;
	private int usersID;
	
	public Comment(){
		
	}
	
	public Comment(int commentID, String content, int moviesID, int usersID){
		super();
		this.commentID=commentID;
		this.content=content;
		this.moviesID=moviesID;
		this.usersID=usersID;
	}

	public int getCommentID() {
		return commentID;
	}

	public void setCommentID(int commentID) {
		this.commentID = commentID;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getMoviesID() {
		return moviesID;
	}

	public void setMoviesID(int moviesID) {
		this.moviesID = moviesID;
	}

	public int getUsersID() {
		return usersID;
	}

	public void setUsersID(int usersID) {
		this.usersID = usersID;
	}
	
	
	
}
