package si.um.feri.praktikum;

public class Vstopnice {
	private int bazniID;
	private double cena;
	private String kraj, vrsta;
	
	public Vstopnice(){
		
	}
	public Vstopnice(int bazniID, double cena, String kraj, String vrsta){
		this.bazniID=bazniID;
		this.cena=cena;
		this.kraj=kraj;
		this.vrsta=vrsta;
	}
	public int getBazniID() {
		return bazniID;
	}
	public void setBazniID(int bazniID) {
		this.bazniID = bazniID;
	}
	public double getCena() {
		return cena;
	}
	public void setCena(double cena) {
		this.cena = cena;
	}
	public String getKraj() {
		return kraj;
	}
	public void setKraj(String kraj) {
		this.kraj = kraj;
	}
	public String getVrsta() {
		return vrsta;
	}
	public void setVrsta(String vrsta) {
		this.vrsta = vrsta;
	}
	
	
}
